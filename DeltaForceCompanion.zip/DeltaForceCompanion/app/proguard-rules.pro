# AndroidX ships its own consumer rules.
-keepattributes SourceFile,LineNumberTable
