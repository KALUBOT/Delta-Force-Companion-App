package com.shushy.deltaforcecompanion

import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.widget.NestedScrollView

class AboutScreen(host: MainActivity) : Screen(host) {

    private val frame = FrameLayout(host)
    private val bar = TopBar(host, "About", { host.goBack() })
    private val column = LinearLayout(host)
    private val scroll = NestedScrollView(host)
    private val items = ArrayList<View>()
    override val view: View get() = frame

    init {
        val ctx = host
        frame.setBackgroundColor(Colors.BG)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(32))
        scroll.clipToPadding = false
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun add(v: View, topMargin: Int = 16, gravity: Int = -1) {
            column.addView(v, LinearLayout.LayoutParams(
                if (gravity == Gravity.CENTER_HORIZONTAL) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
            ).apply { this.topMargin = ctx.dp(topMargin); if (gravity != -1) this.gravity = gravity })
            items.add(v)
        }

        fun card(title: String, body: String): View {
            val c = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(ctx.dp(18), ctx.dp(16), ctx.dp(18), ctx.dp(18))
                background = roundRect(Colors.PANEL, ctx.dpf(18f), Colors.STROKE, ctx.dp(1))
            }
            c.addView(text(ctx, title.uppercase(), 12f, Colors.ACCENT, bold = true, spacing = 0.12f))
            c.addView(text(ctx, body, 14.5f, Colors.BODY).apply { setLineSpacing(ctx.dpf(4f), 1f) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ctx.dp(10) })
            return c
        }

        val logo = ImageView(ctx).apply { setImageResource(R.drawable.logo); roundClip(ctx.dpf(26f)) }
        column.addView(logo, LinearLayout.LayoutParams(ctx.dp(104), ctx.dp(104)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = ctx.dp(8) })
        items.add(logo)
        add(text(ctx, "Delta Force Companion", 22f, Colors.TEXT, bold = true, gravity = Gravity.CENTER), 18)
        add(text(ctx, "Version ${host.versionName()}", 13f, Colors.ACCENT, bold = true, spacing = 0.1f, gravity = Gravity.CENTER), 6)

        add(card("What's new in ${host.versionName()}",
            "• Brand-new immersive interface\n" +
                "• Smooth transitions and animations on every screen\n" +
                "• Announcements & News now open in desktop mode, with free pinch-zoom\n" +
                "• Pull to refresh and a retry screen on every web page\n" +
                "• Full-screen maps in landscape\n" +
                "• Much lighter and faster to open"), 24)
        add(card("About",
            "Delta Force Companion is an unofficial companion app that gives Delta Force players quick access to interactive maps, Headquarters, weapon loadouts and the latest news, all in one place."))
        add(card("Features",
            "• Interactive Maps: AZ3, Brakkesh, Layali Grove, Space City, Tide Prison, Zero Dam\n• Headquarters\n• Weapon Loadouts\n• Announcements & News\n• Discord and YouTube shortcuts\n• Smooth, mobile-friendly interface"))
        add(card("Disclaimer",
            "Delta Force Companion is a fan-made project and is not affiliated with, endorsed by, or sponsored by Level Infinite, TiMi Studio Group, or the official Delta Force developers."))
        add(card("Developer", "TastyShushy"))

        val contact = card("Contact", Links.CONTACT)
        contact.isClickable = true
        contact.setOnClickListener { host.openEmail(Links.CONTACT) }
        contact.pressable()
        add(contact)

        val social = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        social.addView(pillButton(ctx, R.drawable.discord, "Discord") { host.openExternal(Links.DISCORD) })
        social.addView(pillButton(ctx, R.drawable.youtube, "YouTube") { host.openExternal(Links.YOUTUBE) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = ctx.dp(12) })
        add(social, 24)
        add(text(ctx, "©2026 TastyShushy. All rights reserved.", 12f, Colors.MUTED, gravity = Gravity.CENTER), 22)

        hideForEntrance(items, ctx.dpf(26f))
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onInsets(top: Int, bottom: Int) {
        bar.setInsetTop(top)
        column.setPadding(host.dp(20), host.dp(8), host.dp(20), bottom + host.dp(32))
    }

    override fun onShown() = playEntrance(items, startDelay = 140, step = 60)
}
