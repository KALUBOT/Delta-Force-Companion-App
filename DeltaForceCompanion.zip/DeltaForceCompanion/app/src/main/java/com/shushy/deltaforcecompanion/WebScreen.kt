package com.shushy.deltaforcecompanion

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.progressindicator.LinearProgressIndicator

/** Full-screen web page with progress line, pull-to-refresh and a friendly error state. */
class WebScreen(host: MainActivity, private val title: String, private val url: String, desktop: Boolean = false, private val pullToRefresh: Boolean = false) : Screen(host) {

    private val frame = FrameLayout(host)
    private val bar: TopBar
    private val web = WebView(host)
    private val swipe = SwipeRefreshLayout(host)
    private val progress = LinearProgressIndicator(host)
    private val errorView = LinearLayout(host)
    private var failed = false
    private var desktopMode = desktop
    private val mobileUA: String = web.settings.userAgentString

    override val view: View get() = frame
    override val orientation: Int get() = ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
    override val immersiveInLandscape: Boolean get() = true

    init {
        val ctx = host
        frame.setBackgroundColor(Colors.BG)
        bar = TopBar(ctx, title, { host.goBack() }, listOf(
            R.drawable.ic_refresh to { reload() },
            R.drawable.ic_open to { host.openExternal(web.url ?: url) },
        ))

        configureWebView()
        // Desktop-site switch (highlighted when on); the page reloads with the chosen user agent.
        bar.addToggle(R.drawable.ic_desktop, desktopMode, index = 2) { on ->
            desktopMode = on
            web.settings.userAgentString = if (on) DESKTOP_UA else mobileUA
            android.widget.Toast.makeText(host, if (on) "Desktop site on" else "Desktop site off", android.widget.Toast.LENGTH_SHORT).show()
            reload()
        }
        swipe.setColorSchemeColors(Colors.ACCENT)
        swipe.setProgressBackgroundColorSchemeColor(Colors.PANEL)
        swipe.setOnRefreshListener { reload() }
        swipe.setOnChildScrollUpCallback { _, _ -> web.scrollY > 0 }
        // Dragging/pinching must scroll, pan or zoom the page, never trigger pull-to-refresh.
        swipe.isEnabled = pullToRefresh
        run {
            web.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    android.view.MotionEvent.ACTION_DOWN, android.view.MotionEvent.ACTION_POINTER_DOWN ->
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                }
                false
            }
        }
        swipe.addView(web, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        progress.setIndicatorColor(Colors.ACCENT)
        progress.trackColor = Colors.BG
        progress.trackThickness = ctx.dp(3)
        progress.isIndeterminate = false
        progress.max = 100
        progress.visibility = View.INVISIBLE

        // Error state
        errorView.orientation = LinearLayout.VERTICAL
        errorView.gravity = Gravity.CENTER
        errorView.setBackgroundColor(Colors.BG)
        errorView.setPadding(ctx.dp(32), ctx.dp(32), ctx.dp(32), ctx.dp(32))
        errorView.alpha = 0f
        errorView.visibility = View.GONE
        errorView.addView(text(ctx, "Can't reach this page", 20f, Colors.TEXT, bold = true, gravity = Gravity.CENTER))
        errorView.addView(text(ctx, "Check your connection and try again.", 14f, Colors.MUTED, gravity = Gravity.CENTER),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ctx.dp(8); bottomMargin = ctx.dp(24) })
        errorView.addView(pillButton(ctx, R.drawable.ic_refresh, "Retry") { reload() })

        val content = FrameLayout(ctx)
        content.addView(swipe, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        content.addView(errorView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        content.addView(progress, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        web.loadUrl(url)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        web.setBackgroundColor(Colors.BG)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            if (desktopMode) {
                // Desktop mode: desktop user agent, wide viewport, free pinch-zoom.
                userAgentString = DESKTOP_UA
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress < 100) {
                    progress.visibility = View.VISIBLE
                    progress.setProgressCompat(newProgress, true)
                } else {
                    progress.setProgressCompat(100, true)
                    progress.postDelayed({ progress.visibility = View.INVISIBLE }, 250)
                }
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                failed = false
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (desktopMode) view.evaluateJavascript(FORCE_ZOOM_JS, null)
                swipe.isRefreshing = false
                if (!failed) hideError()
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri: Uri = request.url
                val scheme = uri.scheme ?: return false
                if (scheme == "http" || scheme == "https") {
                    val h = uri.host ?: return false
                    val inApp = Links.IN_APP_HOSTS.any { h == it || h.endsWith(".$it") }
                    if (inApp) return false
                }
                host.openExternal(uri.toString())
                return true
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    failed = true
                    swipe.isRefreshing = false
                    showError()
                }
            }
        }
    }

    private fun reload() {
        failed = false
        if (web.url == null) web.loadUrl(url) else web.reload()
    }

    private fun showError() {
        errorView.visibility = View.VISIBLE
        errorView.animate().alpha(1f).setDuration(260).start()
    }

    private fun hideError() {
        if (errorView.visibility != View.VISIBLE) return
        errorView.animate().alpha(0f).setDuration(200).withEndAction { errorView.visibility = View.GONE }.start()
    }

    override fun onInsets(top: Int, bottom: Int) {
        bar.setInsetTop(top)
        frame.setPadding(0, 0, 0, bottom)
    }

    override fun onBack(): Boolean {
        if (web.canGoBack()) { web.goBack(); return true }
        return false
    }

    override fun onPause() { web.onPause() }
    override fun onResume() { web.onResume() }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.stopLoading()
        web.destroy()
    }
}

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

// Makes sure the page keeps a wide layout and can always be pinch-zoomed.
private const val FORCE_ZOOM_JS = """
(function(){
  var m=document.querySelector('meta[name=viewport]');
  if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}
  m.setAttribute('content','width=1280, initial-scale=0.3, minimum-scale=0.2, maximum-scale=5, user-scalable=yes');
})();
"""
