package com.shushy.deltaforcecompanion

import androidx.annotation.DrawableRes

/** Everything the app links to lives here, so a URL change is a one-line edit. */
object Links {
    const val HQ = "https://www.playdeltaforce.com/events/hq/en/m/index.html"
    const val WEAPON_BUILDS = "https://deltaforcetools.gg/weapon-builds"
    const val NEWS = "https://www.playdeltaforce.com/en/news/"
    const val DISCORD = "https://discord.gg/yXBWyBJkAN"
    const val YOUTUBE = "https://youtube.com/@tastyshushyindia?si=bmwsQr3wJJG7VvNi"
    const val CONTACT = "kartik98162@gmail.com"


    /** Hosts that open inside the app. Everything else goes to the browser. */
    val IN_APP_HOSTS = listOf("deltaforcetools.gg", "deltaforcemaps.com", "deltahub.gg", "playdeltaforce.com")
}

data class MapItem(val title: String, val url: String, @DrawableRes val image: Int)

val MAPS = listOf(
    MapItem("AZ3", "https://deltaforcetools.gg/map/az3/2716", R.drawable.az3),
    MapItem("Brakkesh", "https://deltaforcetools.gg/map/brakkesh", R.drawable.brakkesh),
    MapItem("Layali Grove", "https://deltaforcetools.gg/map/layali-grove", R.drawable.layali_grove),
    MapItem("Space City", "https://deltaforcetools.gg/map/space-city", R.drawable.space_city),
    MapItem("Tide Prison", "https://deltahub.gg/map/tide-prison/operations", R.drawable.tide_prison),
    MapItem("Zero Dam", "https://deltaforcetools.gg/map/zero-dam", R.drawable.zero_dam),
)
