package com.shushy.deltaforcecompanion

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object Colors {
    val BG = Color.parseColor("#0D1117")
    val PANEL = Color.parseColor("#161B22")
    val STROKE = Color.parseColor("#26303B")
    val TEXT = Color.parseColor("#F0F6FC")
    val BODY = Color.parseColor("#C9D1D9")
    val MUTED = Color.parseColor("#8B949E")
    val ACCENT = Color.parseColor("#29E58A")
    val ACCENT_SOFT = Color.parseColor("#3329E58A")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun roundRect(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(color)
        cornerRadius = radiusPx
        if (strokePx > 0) setStroke(strokePx, strokeColor)
    }

fun ripple(base: Drawable?, radiusPx: Float, oval: Boolean = false): RippleDrawable {
    val mask = GradientDrawable().apply {
        shape = if (oval) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
        cornerRadius = radiusPx
        setColor(Color.WHITE)
    }
    return RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), base, mask)
}

/** Clips a view to a rounded rectangle. */
fun View.roundClip(radiusPx: Float) {
    outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    clipToOutline = true
}

/** Springy scale-down while pressed, with a small haptic tick on release. */
fun View.pressable(scale: Float = 0.97f) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN ->
                v.animate().scaleX(scale).scaleY(scale).setDuration(110)
                    .setInterpolator(DecelerateInterpolator()).start()
            MotionEvent.ACTION_UP -> {
                v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                v.animate().scaleX(1f).scaleY(1f).setDuration(260)
                    .setInterpolator(OvershootInterpolator(2.2f)).start()
            }
            MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(200)
                    .setInterpolator(DecelerateInterpolator()).start()
        }
        false
    }
}

/** Prepares views so [playEntrance] can slide them in. Call before the first frame. */
fun hideForEntrance(views: List<View>, distancePx: Float) {
    views.forEach { it.alpha = 0f; it.translationY = distancePx }
}

fun playEntrance(views: List<View>, startDelay: Long = 60, step: Long = 70) {
    views.forEachIndexed { i, v ->
        v.animate().alpha(1f).translationY(0f)
            .setStartDelay(startDelay + i * step)
            .setDuration(480)
            .setInterpolator(DecelerateInterpolator(2f))
            .start()
    }
}

fun text(
    ctx: Context, value: CharSequence, sizeSp: Float, color: Int,
    bold: Boolean = false, spacing: Float = 0f, gravity: Int = Gravity.START,
): TextView = TextView(ctx).apply {
    text = value
    textSize = sizeSp
    setTextColor(color)
    if (bold) typeface = Typeface.DEFAULT_BOLD
    letterSpacing = spacing
    this.gravity = gravity
    includeFontPadding = false
}

/** A full-width banner image card with a neon edge, ripple, and press feedback. */
fun bannerCard(ctx: Context, image: Int, description: String, onClick: () -> Unit): View {
    val r = ctx.dpf(20f)
    val card = FrameLayout(ctx).apply {
        background = roundRect(Colors.PANEL, r, Colors.ACCENT_SOFT, ctx.dp(1))
        contentDescription = description
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        pressable()
    }
    val img = ImageView(ctx).apply {
        setImageResource(image)
        adjustViewBounds = true
        scaleType = ImageView.ScaleType.FIT_CENTER
        roundClip(r - ctx.dp(1))
    }
    card.addView(img, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(ctx.dp(1), ctx.dp(1), ctx.dp(1), ctx.dp(1))
    })
    card.foreground = ripple(null, r)
    return card
}

fun pillButton(ctx: Context, icon: Int?, label: String, onClick: () -> Unit): View {
    val row = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(ctx.dp(18), ctx.dp(12), ctx.dp(18), ctx.dp(12))
        background = ripple(roundRect(Colors.PANEL, ctx.dpf(28f), Colors.STROKE, ctx.dp(1)), ctx.dpf(28f))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
        pressable(0.95f)
    }
    if (icon != null) {
        row.addView(ImageView(ctx).apply { setImageResource(icon) }, LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)).apply { marginEnd = ctx.dp(10) })
    }
    row.addView(text(ctx, label, 14f, Colors.TEXT, bold = true))
    return row
}

/** Top bar used by every screen: back button, title, and optional icon actions. */
class TopBar(private val ctx: Context, title: String, onBack: () -> Unit, actions: List<Pair<Int, () -> Unit>> = emptyList()) : LinearLayout(ctx) {
    val titleView: TextView

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(Colors.BG)
        addView(iconButton(R.drawable.ic_back, onBack))
        titleView = text(ctx, title, 17f, Colors.TEXT, bold = true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        addView(titleView, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = ctx.dp(4) })
        actions.forEach { (icon, cb) -> addView(iconButton(icon, cb)) }
        setInsetTop(0)
    }

    fun setInsetTop(top: Int) {
        setPadding(ctx.dp(8), top, ctx.dp(8), 0)
        minimumHeight = top + ctx.dp(56)
    }

    private fun iconButton(icon: Int, cb: () -> Unit): View = ImageView(ctx).apply {
        setImageResource(icon)
        setColorFilter(Colors.TEXT)
        setPadding(ctx.dp(12), ctx.dp(12), ctx.dp(12), ctx.dp(12))
        background = ripple(null, 0f, oval = true)
        isClickable = true
        isFocusable = true
        setOnClickListener { cb() }
        layoutParams = LayoutParams(ctx.dp(48), ctx.dp(48))
        pressable(0.88f)
    }
}

/** Tiny image loader: background fetch, size-aware decode, in-memory cache. */
object Images {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(view: ImageView, url: String?, reqWidth: Int, onDone: (Boolean) -> Unit = {}) {
        view.tag = url
        if (url.isNullOrBlank()) { onDone(false); return }
        val hit = cache.get(url)
        if (hit != null) { view.setImageBitmap(hit); onDone(true); return }
        pool.execute {
            val bmp = try { fetch(url, reqWidth) } catch (e: Exception) { null }
            if (bmp != null) cache.put(url, bmp)
            main.post {
                if (view.tag == url) {
                    if (bmp != null) view.setImageBitmap(bmp)
                    onDone(bmp != null)
                }
            }
        }
    }

    private fun fetch(url: String, reqWidth: Int): Bitmap? {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 10000
        val bytes = conn.inputStream.use { it.readBytes() }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= reqWidth) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }
}
