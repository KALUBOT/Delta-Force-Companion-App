package com.shushy.deltaforcecompanion

import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.core.widget.NestedScrollView

class MapsScreen(host: MainActivity) : Screen(host) {

    private val frame = FrameLayout(host)
    private val bar = TopBar(host, "Interactive Maps", { host.goBack() })
    private val column = LinearLayout(host)
    private val scroll = NestedScrollView(host)
    private val items = ArrayList<View>()
    override val view: View get() = frame

    init {
        val ctx = host
        frame.setBackgroundColor(Colors.BG)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(ctx.dp(20), ctx.dp(8), ctx.dp(20), ctx.dp(24))
        scroll.clipToPadding = false
        scroll.isVerticalScrollBarEnabled = false
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val lead = text(ctx, "Pick a map to explore loot, extracts and points of interest.", 14f, Colors.MUTED)
        column.addView(lead, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = ctx.dp(18) })
        items.add(lead)
        MAPS.forEach { m ->
            val card = bannerCard(ctx, m.image, m.title) { host.push(WebScreen(host, m.title, m.url)) }
            column.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = ctx.dp(16) })
            items.add(card)
        }
        hideForEntrance(items, ctx.dpf(30f))

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        frame.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    override fun onInsets(top: Int, bottom: Int) {
        bar.setInsetTop(top)
        column.setPadding(host.dp(20), host.dp(8), host.dp(20), bottom + host.dp(24))
    }

    override fun onShown() = playEntrance(items, startDelay = 140, step = 80)
}
