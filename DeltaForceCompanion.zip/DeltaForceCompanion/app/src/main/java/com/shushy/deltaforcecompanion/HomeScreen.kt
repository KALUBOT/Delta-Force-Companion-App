package com.shushy.deltaforcecompanion

import android.animation.ValueAnimator
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.widget.NestedScrollView

class HomeScreen(host: MainActivity) : Screen(host) {

    private val frame = FrameLayout(host)
    private val scroll = NestedScrollView(host)
    private val column = LinearLayout(host)
    private val hero = LinearLayout(host)
    private val logo = ImageView(host)
    private val entrance = ArrayList<View>()
    private var floatAnim: ValueAnimator? = null
    private var played = false

    override val view: View get() = frame

    init {
        val ctx = host
        frame.setBackgroundColor(Colors.BG)

        // Soft green glow behind the logo.
        val glow = View(ctx)
        glow.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = ctx.dpf(340f)
            setGradientCenter(0.5f, 0.12f)
            colors = intArrayOf(0x4029E58A, 0x0029E58A)
        }
        frame.addView(glow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        column.orientation = LinearLayout.VERTICAL
        column.setPadding(ctx.dp(20), ctx.dp(28), ctx.dp(20), ctx.dp(32))
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipToPadding = false
        scroll.addView(column, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        frame.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Hero
        hero.orientation = LinearLayout.VERTICAL
        hero.gravity = Gravity.CENTER_HORIZONTAL
        logo.setImageResource(R.drawable.logo)
        logo.roundClip(ctx.dpf(32f))
        hero.addView(logo, LinearLayout.LayoutParams(ctx.dp(128), ctx.dp(128)))
        hero.addView(text(ctx, "DELTA FORCE", 28f, Colors.TEXT, bold = true, spacing = 0.08f, gravity = Gravity.CENTER),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ctx.dp(18) })
        hero.addView(text(ctx, "COMPANION", 13f, Colors.ACCENT, bold = true, spacing = 0.5f, gravity = Gravity.CENTER),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ctx.dp(6) })
        hero.addView(text(ctx, "Maps, builds and intel for every operator", 14f, Colors.MUTED, gravity = Gravity.CENTER),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ctx.dp(10) })
        column.addView(hero, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = ctx.dp(28) })

        // Banner cards
        val cards = listOf(
            bannerCard(ctx, R.drawable.intractive_maps, "Interactive maps") { host.push(MapsScreen(host)) },
            bannerCard(ctx, R.drawable.headquarters, "Headquarters") { host.push(WebScreen(host, "Headquarters", Links.HQ)) },
            bannerCard(ctx, R.drawable.weapon_lodout, "Weapon loadout") { host.push(WebScreen(host, "Weapon Loadout", Links.WEAPON_BUILDS)) },
            bannerCard(ctx, R.drawable.announcements_and_news, "Announcements and news") { host.push(WebScreen(host, "Announcements & News", Links.NEWS, desktop = true)) },
        )
        cards.forEach {
            column.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = ctx.dp(16) })
        }

        // Footer
        val social = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        social.addView(pillButton(ctx, R.drawable.discord, "Discord") { host.openExternal(Links.DISCORD) })
        social.addView(pillButton(ctx, R.drawable.youtube, "YouTube") { host.openExternal(Links.YOUTUBE) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = ctx.dp(12) })
        column.addView(social, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ctx.dp(8) })

        val about = pillButton(ctx, null, "About") { host.push(AboutScreen(host)) }
        column.addView(about, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = ctx.dp(16)
        })
        val ver = text(ctx, "Ver.${host.versionName()}\nBy TastyShushy", 12f, Colors.MUTED, gravity = Gravity.END)
        column.addView(ver, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = ctx.dp(24) })
        entrance.add(ver)

        // Entrance choreography + parallax hero
        entrance.add(logo)
        for (i in 1 until hero.childCount) entrance.add(hero.getChildAt(i))
        entrance.addAll(cards)
        entrance.add(social)
        entrance.add(about)
        hideForEntrance(entrance, ctx.dpf(36f))

        scroll.setOnScrollChangeListener(NestedScrollView.OnScrollChangeListener { _, _, y, _, _ ->
            val f = (y / ctx.dpf(260f)).coerceIn(0f, 1f)
            hero.translationY = y * 0.45f
            hero.alpha = 1f - f * 0.85f
            hero.scaleX = 1f - 0.06f * f
            hero.scaleY = 1f - 0.06f * f
        })
    }

    override fun onInsets(top: Int, bottom: Int) {
        column.setPadding(host.dp(20), top + host.dp(28), host.dp(20), bottom + host.dp(32))
    }

    override fun onShown() {
        if (!played) {
            played = true
            playEntrance(entrance, startDelay = 120, step = 85)
        }
        startFloat()
    }

    override fun onPause() { floatAnim?.cancel() }
    override fun onResume() { startFloat() }
    override fun onDestroy() { floatAnim?.cancel() }

    private fun startFloat() {
        floatAnim?.cancel()
        floatAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2600
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { logo.rotation = (it.animatedValue as Float - 0.5f) * 3f; logo.scaleX = 1f + (it.animatedValue as Float) * 0.03f; logo.scaleY = logo.scaleX }
            start()
        }
    }
}
