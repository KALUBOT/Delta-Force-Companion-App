package com.shushy.deltaforcecompanion

import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** One screen in the app's back stack. */
abstract class Screen(val host: MainActivity) {
    abstract val view: View
    open val orientation: Int = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    open val immersiveInLandscape: Boolean = false
    open fun onInsets(top: Int, bottom: Int) {}
    open fun onShown() {}
    open fun onBack(): Boolean = false
    open fun onPause() {}
    open fun onResume() {}
    open fun onDestroy() {}
}

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private val stack = ArrayList<Screen>()
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    var insetTop = 0
        private set
    var insetBottom = 0
        private set

    private val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() = goBack()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Logo zooms and fades out as the app appears.
        splash.setOnExitAnimationListener { provider ->
            provider.view.animate().alpha(0f).scaleX(1.18f).scaleY(1.18f)
                .setDuration(320).setInterpolator(AccelerateInterpolator())
                .withEndAction { provider.remove() }.start()
        }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowInsetsControllerCompat(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }

        root = FrameLayout(this).apply { setBackgroundColor(Colors.BG) }
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            insetTop = bars.top
            insetBottom = bars.bottom
            stack.forEach { it.onInsets(insetTop, insetBottom) }
            insets
        }

        onBackPressedDispatcher.addCallback(this, backCallback)

        if (stack.isEmpty()) push(HomeScreen(this))
    }

    // ---- navigation -----------------------------------------------------------------------

    fun push(screen: Screen) {
        if (busy) return
        val prev = stack.lastOrNull()
        stack.add(screen)
        root.addView(screen.view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        screen.onInsets(insetTop, insetBottom)
        applyScreenConfig()
        backCallback.isEnabled = stack.size > 1
        if (prev == null) {
            screen.onShown()
            return
        }
        lockFor(360)
        screen.view.alpha = 0f
        screen.view.translationX = dp(40).toFloat()
        screen.view.animate().alpha(1f).translationX(0f)
            .setDuration(360).setInterpolator(DecelerateInterpolator(1.8f)).start()
        prev.view.animate().translationX(-root.width * 0.18f).alpha(0.35f).scaleX(0.95f).scaleY(0.95f)
            .setDuration(360).setInterpolator(DecelerateInterpolator())
            .withEndAction { prev.view.visibility = View.INVISIBLE; prev.onPause() }.start()
        screen.onShown()
    }

    fun goBack() {
        if (busy) return
        val top = stack.lastOrNull() ?: return
        if (top.onBack()) return
        if (stack.size <= 1) { finish(); return }
        lockFor(300)
        stack.removeAt(stack.size - 1)
        val prev = stack.last()
        prev.view.visibility = View.VISIBLE
        prev.onResume()
        prev.view.animate().translationX(0f).alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(320).setInterpolator(DecelerateInterpolator(1.6f)).start()
        top.view.animate().translationX(dp(56).toFloat()).alpha(0f)
            .setDuration(260).setInterpolator(AccelerateInterpolator())
            .withEndAction { root.removeView(top.view); top.onDestroy() }.start()
        applyScreenConfig()
        backCallback.isEnabled = stack.size > 1
    }

    private fun lockFor(ms: Long) {
        busy = true
        handler.postDelayed({ busy = false }, ms)
    }

    private fun applyScreenConfig() {
        val top = stack.lastOrNull() ?: return
        requestedOrientation = top.orientation
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        if (landscape && top.immersiveInLandscape) {
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyScreenConfig()
    }

    // ---- helpers screens use --------------------------------------------------------------

    fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            Toast.makeText(this, "No app can open this link", Toast.LENGTH_SHORT).show()
        }
    }

    fun openEmail(address: String) {
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$address")))
        } catch (e: Exception) {
            Toast.makeText(this, address, Toast.LENGTH_LONG).show()
        }
    }

    fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "2.2"
    } catch (e: Exception) {
        "2.2"
    }

    // ---- lifecycle ------------------------------------------------------------------------

    override fun onPause() {
        super.onPause()
        stack.lastOrNull()?.onPause()
    }

    override fun onResume() {
        super.onResume()
        stack.lastOrNull()?.onResume()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stack.forEach { it.onDestroy() }
        super.onDestroy()
    }
}
