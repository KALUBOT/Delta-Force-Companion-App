# Delta Force Companion

Unofficial companion app for **Delta Force**: interactive maps, Headquarters, weapon loadouts and live announcements in one place.

**Version 2.2** — a full redesign with an immersive, animated interface.

## What's new in 2.2
- Edge-to-edge, immersive dark UI with a neon-green accent
- Animated splash, staggered card entrances, parallax hero, springy press feedback
- Smooth slide/fade transitions between every screen, predictive back gesture support
- Map and web pages: progress line, pull-to-refresh, retry screen, landscape full-screen
- Announcements & News open in desktop mode with pinch-zoom
- Images shrunk from ~20 MB to ~1.2 MB, so the app opens and scrolls faster

## Screens
| Screen | Source |
|---|---|
| Interactive Maps (AZ3, Brakkesh, Layali Grove, Space City, Tide Prison, Zero Dam) | deltaforcetools.gg / deltaforcemaps.com |
| Headquarters | playdeltaforce.com |
| Weapon Loadout | deltaforcetools.gg/weapon-builds |
| Announcements & News | playdeltaforce.com (desktop mode) |

All links live in [`Data.kt`](app/src/main/java/com/shushy/deltaforcecompanion/Data.kt).

## Get the APK
Every push to `main` builds an APK with GitHub Actions: open the **Actions** tab, pick the latest run and download **DeltaForceCompanion-APK**.

To publish a release with the APK attached:

```bash
git tag v2.2
git push origin v2.2
```

> The release APK is signed with the debug key so it installs right away. If you have the old 2.1 build installed, uninstall it first (different signing key). Use your own keystore if you publish to the Play Store.

## Build locally
Requires JDK 17 and the Android SDK (API 35).

```bash
gradle assembleRelease
```

## Tech
Kotlin, plain Android Views (no XML layouts), Material 3. minSdk 21, targetSdk 35.

## Disclaimer
Fan-made project, not affiliated with, endorsed by, or sponsored by Level Infinite, TiMi Studio Group, or the official Delta Force developers.

Made by TastyShushy.
